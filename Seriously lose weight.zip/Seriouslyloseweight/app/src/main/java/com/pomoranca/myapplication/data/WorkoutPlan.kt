package com.pomoranca.myapplication.data

class WorkoutPlan(
    val name: String,
    val duration: Int,
    val backgroudPath: Int
) {
}