package com.pomoranca.myapplication.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import com.pomoranca.myapplication.R
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        welcomeConfirmButton.setOnClickListener {
            if (TextUtils.isEmpty(welcomeCardInput.text)) {
                welcomeCardInput.error = "You don't have a name ? Come on"
            } else {
                val intent  =  Intent(this, MainActivity::class.java)
                intent.putExtra("name" , welcomeCardInput.text.toString())
                startActivity(intent)
            }
        }
    }
}
